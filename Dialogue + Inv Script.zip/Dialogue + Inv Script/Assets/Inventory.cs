﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public List<Item> Inv = new List<Item>();

    public static bool showInv;
    public static Item selectedItem;
    public bool pickedUp;

    public float scrW;
    public float scrH;

    public GameObject item;
    public static GameObject person;

    // Use this for initialization
    void Start()
    {
        person = GameObject.FindGameObjectWithTag("Player");
        showInv = false;
        Inv = new List<Item>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            if (showInv)
            {
                showInv = false;
            }
            else if (!showInv)
            {
                showInv = true;
            }
        }

        if (showInv)
        {
            if (!pickedUp)
            {
                item.SetActive(false);
            }
            
            person.SetActive(false);
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                showInv = false;
            }
        }
        else if (!showInv)
        {
            item.SetActive(true);
            person.SetActive(true);
        }
        if (Dialogue.showDlg)
        {
            if (!pickedUp)
            {
                item.SetActive(false);
            }
            person.SetActive(false);
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Dialogue.showDlg = false;
            }
        }
        else if (!Dialogue.showDlg)
        {
            item.SetActive(true);
            person.SetActive(true);
        }
    }

    void OnGUI()
    {
        scrW = Screen.width / 16;
        scrH = Screen.height / 9;

        if (showInv && !Dialogue.showDlg)
        {
            GUI.Box(new Rect(0, 0, Screen.width, Screen.height), "inventory");
            for (int i = 0; i < Inv.Count; i++)
            {
                if (GUI.Button(new Rect(0.5f * scrW, 0.25f * scrH + i * (0.25f * scrH), 3 * scrW, 0.25f * scrH), Inv[i].Name))
                {
                    selectedItem = Inv[i];
                    Debug.Log(selectedItem.Name);
                }
            }
        }
    }

    public void OpenDlg()
    {
        Dialogue.showDlg = true;
        this.gameObject.SetActive(false);
    }

    public void PickUp()
    {
        Inv.Add(ItemData.CreateItem(001));
        this.gameObject.SetActive(false);
        pickedUp = true;
    }


}
