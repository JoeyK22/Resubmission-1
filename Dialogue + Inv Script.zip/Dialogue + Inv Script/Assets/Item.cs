﻿using UnityEngine;

public class Item
{
    private int _IDNum;
    private string _Name;
    private Texture2D _Icon;

    public void ItemConstructor(int itemID, string itemName, Texture2D itemIcon)
    {
        _IDNum = itemID;
        _Name = itemName;
        _Icon = itemIcon;
    }

    public int ID
    {
        get { return _IDNum; }
        set { _IDNum = value; }
    }

    public string Name
    {
        get { return _Name; }
        set { _Name = value; }
    }

    public Texture2D Icon
    {
        get { return _Icon; }
        set { _Icon = value; }
    }


}
