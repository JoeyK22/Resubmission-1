﻿using System.Collections;
using UnityEngine;

public class ItemHandler : MonoBehaviour
{
    public int IDNum;
    public string itemName;
    public string icon;

    public void OnCollection()
    {
        Item temp = new Item();
        temp.ID = IDNum;
        temp.Name = itemName;
        temp.Icon = Resources.Load("Icons/" + icon) as Texture2D;

        Inventory inventory = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Inventory>();
    }
}
