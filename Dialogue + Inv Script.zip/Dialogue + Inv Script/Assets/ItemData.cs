﻿using UnityEngine;

public static class ItemData
{
    public static Item CreateItem(int ItemID)
    {
        Item temp = new Item();
        string name = "";
        string icon = "";

        switch (ItemID)
        {
            case 001:
                {
                    ItemID = 001;
                    name = "Sugar";
                    icon = "fileIcon";
                    break;
                }


            default:
                ItemID = 000;
                name = "Apple";
                icon = "appleIcon";
                break;
        }
        temp.Name = name;
        temp.ID = ItemID;
        temp.Icon = Resources.Load("Icons/" + icon) as Texture2D;

        return temp;
    }
}