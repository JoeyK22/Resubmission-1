﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dialogue : MonoBehaviour
{
    #region GameStuff

    public bool dlgComplete;
    public bool gotCoffee;
    public bool Outcome;

    public GameObject win;
    public GameObject failure;

    public float endgameTimer;
    #endregion
    public static bool showDlg;
    float scrW;
    float scrH;

    public string[] negText, neuText, posText; //declaring each different chain of texts
    public int approval;
    public string resp1, resp2;
    public int index, optIndex;
    public string NPCName;
    private string[] txt;


    // Use this for initialization
    void Start()
    {
        Time.timeScale = 1;
        dlgComplete = false;
        showDlg = false;

        txt = new string[5];
        for (int i = 0; i < txt.Length; i++)
        {
            txt[i] = neuText[i];
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Outcome)
        {
            endgameTimer += Time.deltaTime;
        }

        if (endgameTimer >= 2)
        {
            if (gotCoffee)
            {
                win.SetActive(true);
            }
            else if (!gotCoffee)
            {
                failure.SetActive(true);
            }
        }

        if (approval <= -1)
        {
            txt = negText;
        }

        if (approval == 0)
        {
            txt = neuText;
        }

        if (approval == 1)
        {
            txt = posText;
        }
    }
    public void Restart()
    {

    }

    void OnGUI()
    {
        if (showDlg && !Inventory.showInv)
        {
            scrW = Screen.width / 16;
            scrH = Screen.height / 9;

            GUI.Box(new Rect(0 * scrW, 7.5f * scrH, 16 * scrW, 1.5f * scrH), NPCName + ": " + txt[index]);

            if (!(index + 1 >= txt.Length || index == optIndex))
            {
                if (GUI.Button(new Rect(13.5f * scrW, 8 * scrH, 2.5f * scrW, 1 * scrH), "next"))
                {
                    index++;
                }
            }
            else if (index == optIndex)
            {
                if (GUI.Button(new Rect(14 * scrW, 8.5f * scrH, scrW, 0.5f * scrH), "Coffee"))
                {
                    approval++;
                    index++;
                    gotCoffee = true;
                }
                if (GUI.Button(new Rect(15 * scrW, 8.5f * scrH, scrW, 0.5f * scrH), "Tea"))
                {
                    approval--;
                    index += 2;
                }
            }

            else
            {
                if (GUI.Button(new Rect(6.5f * scrW, 8 * scrH, 2.75f * scrW, 1 * scrH), "Thanks"))
                {
                    showDlg = false;
                    index = 0;
                    Outcome = true;
                    Inventory.person.SetActive(true);
                }
            }
        }
    }
}
